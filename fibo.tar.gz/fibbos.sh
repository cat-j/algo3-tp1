python prueba.py > res.txt
python graficador.py < res.txt
rm res.txt